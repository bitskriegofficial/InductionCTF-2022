I wish I found some better sounds no one's ever heard
I wish I had a better voice that sang some better words
I wish I found some chords in an order that is new
I wish I didn't have to rhyme every time I sang
I was told when I get older, all my fears would shrink
But now I'm insecure, and I care what people think
My name's Blurryface and I care what you think
My name's Blurryface and I care what you think
**Wish we could turn back time**
To the good old days
When our mama sang us to sleep
But now we're stressed out (oh)
**Wish we could turn back time** (oh)
To the good old days (oh)
When our mama sang us to sleep
But now we're stressed out
We're stressed out
Sometimes a certain smell will take me back to when I was young
How come I'm never able to identify where it's coming from?
I'd make a candle out of it if I ever found it
Try to sell it, never sell out of it, I'd probably only sell one
It'd be to my brother, 'cause we have the same nose
Same clothes, homegrown, a stone's throw from a creek we used to roam
But it would remind us of when nothing really mattered
Out of student loans and tree house homes, we all would take the latter
My name's Blurryface and I care what you think
My name's Blurryface and I care what you think
**Wish we could turn back time**
To the good old days
When our mama sang us to sleep
But now we're stressed out (oh)
**Wish we could turn back time** (oh)
To the good old days (oh)
When our mama sang us to sleep
But now we're stressed out
Used to play pretend, give each other different names
We would build a rocket ship and then we'd fly it far away
Used to dream of outer space, but now they're laughing at our face saying
"Wake up, you need to make money", yeah
We used to play pretend, give each other different names
We would build a rocket ship and then we'd fly it far away
Used to dream of outer space, but now they're laughing at our face saying
"Wake up, you need to make money", yeah
**Wish we could turn back time**
To the good old days
When our mama sang us to sleep
But now we're stressed out (oh)
**Wish we could turn back time** (oh)
To the good old days (oh)
When our mama sang us to sleep
But now we're stressed out
We used to play pretend, used to play pretend, money
We used to play pretend, wake up, you need the money
Used to play pretend, used to play pretend, money
We used to play pretend, wake up, you need the money
Used to play pretend, give each other different names
We would build a rocket ship and then we'd fly it far away
Used to dream of outer space, but now they're laughing at our face saying
"Wake up, you need to make money", yeah

Source: https://youtu.be/pXRviuL6vMY