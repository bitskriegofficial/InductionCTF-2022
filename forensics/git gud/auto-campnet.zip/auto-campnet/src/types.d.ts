type Credentials = {
    username: string;
    password: string;
}

export {
    Credentials
}